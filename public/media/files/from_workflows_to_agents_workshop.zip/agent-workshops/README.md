# From Workflows to Agents: Building LLM Systems in Practice

This directory contains the notebook and support code for a 40-45 minute workshop built around one cohesive dummy project: a local support/helpdesk ticket assistant.

## Setup

Use `uv` with Python 3.11 or newer.

```bash
uv sync
cp .env.example .env
```

Populate `.env` with Azure OpenAI values for your deployment. The main deployment should point to your Azure-hosted `gpt-5.1` deployment.

Required variables:

- `OPENAI_AZURE_ENDPOINT_GPT`
- `OPENAI_API_KEY_GPT`
- `OPENAI_API_VERSION_GPT`
- `OPENAI_MODEL_NAME`
- `OPENAI_MODEL_VERSION_GPT`

Optional LangSmith variables for tracing:

- `LANGSMITH_TRACING=true`
- `LANGSMITH_API_KEY`
- `LANGSMITH_PROJECT`
- `LANGSMITH_ENDPOINT`

## Run

```bash
uv run jupyter notebook from_workflows_to_agents.ipynb
```

## Workshop shape

The notebook demonstrates:

1. a plain LLM call
2. a structured-output call
3. a deterministic workflow
4. a bounded tool-using agent
5. evaluation on a JSONL dataset
6. optional LLM-as-a-judge evaluation

Tracing is wired with LangSmith in two layers:

- LangChain and LangGraph model calls are traced automatically when LangSmith is enabled.
- Local Python boundaries are decorated with `@traceable`, including tools, workflow steps, agent entrypoints, and evaluation helpers.

The judge uses the same Azure OpenAI model configuration as the rest of the workshop.

Everything besides Azure model calls is local and mocked for live-demo reliability.

## Tests

Run the deterministic test suite and coverage report with:

```bash
uv run pytest
```

The tests focus on the local tools, workflow rules, agent control flow, and evaluation helpers rather than live Azure model calls.

Run Ruff periodically to keep imports and basic style issues under control:

```bash
uv run ruff check .
```
