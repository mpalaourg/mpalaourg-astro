"""Workshop package for the 'From Workflows to Agents' session."""
