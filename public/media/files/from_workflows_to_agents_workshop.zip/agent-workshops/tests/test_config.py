"""Tests for local configuration helpers."""

from __future__ import annotations

from src import config


def test_load_settings_reads_environment(monkeypatch) -> None:
    """Load settings from environment variables."""
    monkeypatch.setenv("OPENAI_AZURE_ENDPOINT_GPT", "https://example.openai.azure.com/")
    monkeypatch.setenv("OPENAI_API_KEY_GPT", "secret")
    monkeypatch.setenv("OPENAI_API_VERSION_GPT", "2025-04-01-preview")
    monkeypatch.setenv("OPENAI_MODEL_NAME", "gpt-5.1")
    monkeypatch.setenv("OPENAI_MODEL_VERSION_GPT", "2025-08-07")
    monkeypatch.setenv("LANGSMITH_TRACING", "true")
    monkeypatch.setenv("LANGSMITH_API_KEY", "ls-secret")
    monkeypatch.setenv("LANGSMITH_PROJECT", "workshop-demo")
    monkeypatch.setenv("LANGSMITH_ENDPOINT", "https://api.smith.langchain.com")

    settings = config.load_settings()

    assert settings.openai_azure_endpoint_gpt == "https://example.openai.azure.com/"
    assert settings.openai_model_version_gpt == "2025-08-07"
    assert settings.langsmith_tracing is True
    assert settings.langsmith_project == "workshop-demo"

def test_build_autogen_model_client_raises_when_missing() -> None:
    """Raise a clear error when AutoGen is unavailable."""
    original = config.AzureOpenAIChatCompletionClient
    config.AzureOpenAIChatCompletionClient = None
    try:
        try:
            config.build_autogen_model_client()
        except ImportError as exc:
            assert "uv project dependencies" in str(exc)
        else:  # pragma: no cover - defensive
            raise AssertionError("Expected ImportError to be raised.")
    finally:
        config.AzureOpenAIChatCompletionClient = original


def test_sdk_builders_forward_expected_settings(monkeypatch) -> None:
    """Pass Azure settings through to SDK constructors."""
    monkeypatch.setenv("OPENAI_AZURE_ENDPOINT_GPT", "https://example.openai.azure.com/")
    monkeypatch.setenv("OPENAI_API_KEY_GPT", "secret")
    monkeypatch.setenv("OPENAI_API_VERSION_GPT", "2025-04-01-preview")
    monkeypatch.setenv("OPENAI_MODEL_NAME", "gpt-5.1")
    monkeypatch.setenv("OPENAI_MODEL_VERSION_GPT", "2025-08-07")

    captured: dict[str, dict] = {}

    class FakeAzureChatOpenAI:
        """Capture LangChain constructor arguments."""

        def __init__(self, **kwargs) -> None:
            """Store keyword arguments for assertions."""
            captured["langchain"] = kwargs

    class FakeAzureOpenAI:
        """Capture OpenAI SDK constructor arguments."""

        def __init__(self, **kwargs) -> None:
            """Store keyword arguments for assertions."""
            captured["sdk"] = kwargs

    monkeypatch.setattr(config, "AzureChatOpenAI", FakeAzureChatOpenAI)
    monkeypatch.setattr(config, "AzureOpenAI", FakeAzureOpenAI)

    config.build_langchain_llm(temperature=0.2, max_retries=5)
    config.build_openai_azure_client()

    assert captured["langchain"]["model"] == "gpt-5.1"
    assert captured["langchain"]["model_version"] == "2025-08-07"
    assert captured["langchain"]["temperature"] == 0.2
    assert captured["sdk"]["api_version"] == "2025-04-01-preview"


def test_autogen_builder_passes_model_info(monkeypatch) -> None:
    """Pass model_info to AutoGen for Azure deployment names."""
    monkeypatch.setenv("OPENAI_AZURE_ENDPOINT_GPT", "https://example.openai.azure.com/")
    monkeypatch.setenv("OPENAI_API_KEY_GPT", "secret")
    monkeypatch.setenv("OPENAI_API_VERSION_GPT", "2025-04-01-preview")
    monkeypatch.setenv("OPENAI_MODEL_NAME", "my-gpt5-deployment")
    monkeypatch.setenv("OPENAI_MODEL_VERSION_GPT", "2025-08-07")

    captured: dict[str, dict] = {}

    class FakeAutoGenClient:
        """Capture AutoGen constructor arguments."""

        def __init__(self, **kwargs) -> None:
            """Store keyword arguments for assertions."""
            captured["autogen"] = kwargs

    monkeypatch.setattr(config, "AzureOpenAIChatCompletionClient", FakeAutoGenClient)

    config.build_autogen_model_client()

    assert captured["autogen"]["azure_deployment"] == "my-gpt5-deployment"
    assert captured["autogen"]["model"] == "my-gpt5-deployment-2025-08-07"
    assert captured["autogen"]["model_info"]["family"] == "gpt-5"
    assert captured["autogen"]["model_info"]["function_calling"] is True


def test_langsmith_env_returns_expected_values(monkeypatch) -> None:
    """Expose LangSmith config in a notebook-friendly shape."""
    monkeypatch.setenv("OPENAI_AZURE_ENDPOINT_GPT", "https://example.openai.azure.com/")
    monkeypatch.setenv("OPENAI_API_KEY_GPT", "secret")
    monkeypatch.setenv("OPENAI_API_VERSION_GPT", "2025-04-01-preview")
    monkeypatch.setenv("OPENAI_MODEL_NAME", "gpt-5.1")
    monkeypatch.setenv("OPENAI_MODEL_VERSION_GPT", "2025-08-07")
    monkeypatch.setenv("LANGSMITH_TRACING", "true")
    monkeypatch.setenv("LANGSMITH_API_KEY", "ls-secret")
    monkeypatch.setenv("LANGSMITH_PROJECT", "workshop-demo")

    env = config.langsmith_env()

    assert env["LANGSMITH_TRACING"] == "true"
    assert env["LANGSMITH_PROJECT"] == "workshop-demo"
    assert env["LANGSMITH_API_KEY"] == "ls-secret"
